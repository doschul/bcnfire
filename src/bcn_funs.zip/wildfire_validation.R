#### validate actual burning patterns ####

setwd("C:/Users/DaSchulz/OneDrive - European Forest Institute/Dokumente/research/bcnfire")

# load all shp files in subfolder of ./data/wildfires/wildfires_shp
library(sf)
library(tidyverse)
library(stringr)
library(data.table)
library(decisionSupport)
#library(mapview)

perc_data_long <- readRDS(file = "./data/rdat/perc_data_long.rds")

##### Calibration #####
# select median values for BAU scenario (all years, durations)
BAU_median_area <- perc_data_long %>%
  filter(sal_int == 0,
         strategy == "Random", 
         percentile %in% c(0.01, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.99))

ggplot(BAU_median_area, 
       aes(x=burned_land_ha, y = factor(percentile))) +
  ggridges::geom_density_ridges()

ggplot(BAU_median_area, 
       aes(x=burned_land_ha, y = factor(percentile))) +
  ggridges::geom_density_ridges()

# admin data
comarcas <- st_read("./data/divisions-administratives-v2r1-20250101/divisions-administratives-v2r1-comarques-1000000-20250101.json")
#municips <- st_read("./data/divisions-administratives-v2r1-20250101/divisions-administratives-v2r1-municipis-1000000-20250101.json")
#vegueris <- st_read("./data/divisions-administratives-v2r1-20250101/divisions-administratives-v2r1-vegueries-1000000-20250101.json")


# load grd shape
grd <- st_read("./data/rdat/grd_filt.gpkg")

# load simulated fire data


# convez hull polygon
ch <- st_convex_hull(st_union(grd)) %>%
  st_as_sf() %>%
  st_make_valid()

com_aoi <- c("Alt Penedès", "Baix Llobregat", "Barcelonès",
             "Garraf", "Maresme", "Vallès Occidental", "Vallès Oriental")

#comarcas AOI
comarcas_aoi <- st_transform(comarcas, crs = st_crs(grd)) %>%
  st_make_valid() %>%
  filter(NOMCOMAR %in% com_aoi)

# plot comarcas and ch
# mapview(comarcas_aoi, legend = TRUE, layer.name = "Comarcas") +
#   mapview(ch, color = "black", lwd = 2, layer.name = "Convex Hull")

# par(mfrow = c(1, 1))
# 
wf_df <- read.csv("./data/wildfires/Incendis_forestals_a_Catalunya._Anys_2011-2023_20250725.csv", stringsAsFactors = FALSE)
wf_df$year <- as.integer(substr(wf_df$DATA.INCENDI, 7, 10))

# histogram events per year
wf_df %>%
  filter(COMARCA %in% com_aoi) %>%
  filter(HAFORESTAL>4) %>%
  group_by(year) %>%
  summarise(events = n()) %>%
  View()


# create theoretical distribution and plot below
num_simulations <- 10000

rho_annual_fire_frequency  <- list(distribution = "exp", 
                                   probabilities = c(0.5), 
                                   quantiles = c(1))

rho_avg_fire_duration  <- list(distribution = "exp", 
                               probabilities = c(0.5), 
                               quantiles = c(30))

sim_dt <- data.table(
  annual_fire_frequency = decisionSupport::random(rho_annual_fire_frequency, n = num_simulations),
  avg_fire_duration = decisionSupport::random(rho_avg_fire_duration, n = num_simulations)
)


# bivariate histogram
library(ggplot2)

# histogram of total burned area
wf_df %>%
  filter(year >=2015) %>%
  filter(COMARCA %in% com_aoi) %>%
  filter(HAFORESTAL>4) %>%
  ggplot(aes(x = HAFORESTAL)) +
  geom_histogram(bins = 30, fill = "blue", alpha = 0.7) +
  labs(title = "Distribution of Total Burned Area (ha)",
       x = "Total Burned Area (ha)",
       y = "Frequency") +
  theme_minimal()

# histogram of simulated annual fire frequency
ggplot(sim_dt, aes(x = avg_fire_duration)) +
  geom_histogram(bins = 30, fill = "green", alpha = 0.7) +
  labs(title = "Distribution of Simulated Annual Fire Duration",
       x = "Avg. Fire Duration",
       y = "Frequency") +
  theme_minimal()

ggplot(sim_dt, aes(x = annual_fire_frequency)) +
  geom_histogram(bins = 30, fill = "green", alpha = 0.7) +
  labs(title = "Distribution of Simulated Annual Fire Frequency",
       x = "Annual Fire Frequency",
       y = "Frequency") +
  theme_minimal()


ggplot(sim_dt, aes(x = annual_fire_frequency, y = avg_fire_duration)) +
  geom_bin2d(bins = 300) +
  scale_fill_gradient(low = "blue", high = "red") +
  labs(title = "Bivariate Histogram of Fire Frequency and Duration",
       x = "Annual Fire Frequency",
       y = "Average Fire Duration (days)") +
  theme_minimal()




# 
# table(wf_df$total_burned_ha > 0)
# table(wf_df$total_burned_ha > 4)
# 
# hist(wf_df$total_burned_ha[wf_df$total_burned_ha > 0 & wf_df$total_burned_ha < 1])

wildfires <- list.files("./data/wildfires/wildfires_shp", pattern = ".shp$", 
                        recursive = TRUE, full.names = TRUE, include.dirs = TRUE) |>
  lapply(st_read) |>
  bind_rows()

wildfires <- wildfires |>
  filter(!is.na(CODI_FINAL)) |>
  mutate(
    year = case_when(nchar(DATA_INCEN) == 7 ~ as.integer(paste0("20", substr(DATA_INCEN, 6, 7))),
                     nchar(DATA_INCEN) == 8 ~ as.integer(paste0("20", substr(DATA_INCEN, 7, 8))),
                     nchar(DATA_INCEN) >= 10 ~ as.integer(substr(DATA_INCEN, 7, 10)),
                     TRUE ~ NA),
    month = case_when(nchar(DATA_INCEN) == 7 ~ as.integer(substr(DATA_INCEN, 3, 4)),
                     nchar(DATA_INCEN) >= 8 ~ as.integer(substr(DATA_INCEN, 4, 5)),
                     TRUE ~ NA),
    # day is anything before first slash
    day = as.integer(substring(DATA_INCEN, 1, regexpr("/", DATA_INCEN) - 1)),
    date = as.Date(paste(year, month, day, sep = "-"), format = "%Y-%m-%d"),
    area_ha = as.numeric(st_area(geometry)) / 10000,  # convert from m² to ha
    MUNICIPI = str_to_title(MUNICIPI)  # capitalize first letter of each word
  ) |>
  select(CODI_FINAL, MUNICIPI, date, year, month, area_ha, geometry)


# transform crs
wildfires <- st_transform(wildfires, crs = st_crs(grd)) %>%
  st_make_valid()


# wildfires within study region between 2015 and 2025
wf_aoi <- wildfires |>
  # valid geom only
  filter(st_is_valid(geometry)) |>
  mutate(log_area_ha = log(area_ha)) #|> filter(year >= 2015 & year <= 2025)


# export for use in Python
wf_observed <- wf_aoi %>%
  st_set_geometry(NULL)
write_csv(wf_observed, "./data/wildfires/wf_observed.csv")
wf_observed <- read_csv("./data/wildfires/wf_observed.csv")

wf_aoi <- wf_observed

wf_aoi <- wf_aoi[st_intersects(wf_aoi, ch, sparse = FALSE), ]

# Load necessary libraries
library(dplyr)
library(ggplot2)
library(ggpubr)
library(scales) 
library(MASS) # Added for the fitdistr function


data_summary <- wf_aoi %>%
  st_set_geometry(NULL) %>%
  # Group and summarise the observed data
  group_by(year) %>%
  summarise(
    n = n(),
    area_tot = sum(area_ha),
    .groups = 'drop' # Recommended to drop grouping immediately after summarise
  ) %>%
  # Complete the time series
  complete(
    year = seq(min(year), max(year)), # Create the sequence of all years in the observed range
    fill = list(n = 0, area_tot = 0)  # Fill missing rows with zeros
  )


# --- 2. CALCULATE SCALING FACTOR ---
# The line data (area_tot) must be scaled down to fit the bar data (n) scale.
# The scaling factor is the ratio of the maximum values of the two metrics.
scaling_factor <- max(data_summary$area_tot) / max(data_summary$n)


# --- 3. CREATE DUAL-AXIS PLOT (p1) ---
p1 <- data_summary %>%
  ggplot(aes(x = year)) +
  
  # 1. Bar Geometry (Primary Axis: Frequency 'n')
  geom_col(
    aes(y = n),
    fill = "#1f78b4", # Blue color for bars
    alpha = 0.7 
  ) +
  
  # 2. Line Geometry (Secondary Axis: Area 'area_tot')
  # We divide 'area_tot' by the scaling_factor to plot it on the primary 'n' scale.
  geom_line(
    aes(y = area_tot / scaling_factor, group = 1),
    color = "#e31a1c", # Red color for line
    linewidth = 1.2
  ) +
  # Add points to the line for visual clarity
  geom_point(
    aes(y = area_tot / scaling_factor),
    color = "#e31a1c",
    size = 3
  ) +
  
  # 3. Define the Y-Axis Scales
  scale_y_continuous(
    # Primary Y-Axis (Left) - for the bars ('n')
    name = "Frequency (Count)",
    
    # Secondary Y-Axis (Right) - for the line ('area_tot')
    sec.axis = sec_axis(
      trans = ~ . * scaling_factor,
      name = "Total Area (ha)"
    )
  ) +
  
  # 4. Enhance Aesthetics
  scale_x_continuous(
    name = "Year",
    breaks = data_summary$year, 
    guide = guide_axis(n.dodge = 2) 
  ) +
  labs(
    title = "A: Annual Event Frequency and Total Area",
    subtitle = paste0("Scaling Factor: ", round(scaling_factor, 2))
  ) +
  theme_minimal() +
  theme(
    # Custom colors to match the geoms
    axis.title.y.left = element_text(color = "#1f78b4", margin = margin(r = 10)),
    axis.text.y.left = element_text(color = "#1f78b4"),
    axis.title.y.right = element_text(color = "#e31a1c", margin = margin(l = 10)),
    axis.text.y.right = element_text(color = "#e31a1c"),
    plot.title = element_text(hjust = 0.5, size = 11, face = "bold"),
    plot.subtitle = element_text(hjust = 0.5, size = 9),
    plot.margin = margin(5, 5, 5, 5) 
  )


# --- 4. CREATE FREQUENCY HISTOGRAM (p2) - WITH FITTED COUNT DISTRIBUTIONS ---

# Fit Poisson and Negative Binomial distributions to the annual event counts (n)
counts <- data_summary$n
fit_pois <- MASS::fitdistr(counts, "poisson")
fit_nbinom <- MASS::fitdistr(counts, "negative binomial")

# Prepare data frame for plotting the fitted lines
max_count <- max(counts)
x_val <- min(counts):max_count
df_fit_counts <- data.frame(n = x_val)

# Calculate theoretical counts (PMF * Total Observations, which is 10 years)
df_fit_counts <- df_fit_counts %>%
  mutate(
    pois_expected = dpois(n, lambda = fit_pois$estimate["lambda"]) * length(counts),
    nbinom_expected = dnbinom(n, size = fit_nbinom$estimate["size"], mu = fit_nbinom$estimate["mu"]) * length(counts)
  )

# Extract parameters for annotation
pois_lambda <- format(fit_pois$estimate["lambda"], digits = 3)
nbinom_mu <- format(fit_nbinom$estimate["mu"], digits = 3)
nbinom_size <- format(fit_nbinom$estimate["size"], digits = 3)
p2_subtitle <- paste0(
  "Poisson [dashed] (\u03bb): ", pois_lambda, 
  " | NegBin [dotted] (\u03bc, size): ", nbinom_mu, ", ", nbinom_size
)

p2 <- data_summary %>%
  ggplot(aes(x = n)) +
  # Note: binwidth is used here to group the 10 annual counts for visualization
  geom_histogram(bins = max_count, fill = "#a6cee3", color = "white") + 
  
  # Add fitted distributions (plotted as expected counts/frequencies)
  geom_line(data = df_fit_counts, aes(x = n, y = pois_expected), 
            color = "#1b9e77", linewidth = 1, linetype = "dashed") + # Green for Poisson
  geom_line(data = df_fit_counts, aes(x = n, y = nbinom_expected), 
            color = "#d95f02", linewidth = 1, linetype = "dotted") + # Orange for NegBin
  
  labs(
    title = "B: Annual Event Frequency Distribution",
    subtitle = p2_subtitle,
    x = "Events per Year (n)",
    y = "Count of Years (Frequency)"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 11, hjust = 0.5, face = "bold"),
    plot.subtitle = element_text(size = 8, hjust = 0.5),
    plot.margin = margin(5, 5, 5, 5) 
  )


# --- 5. CREATE AREA PER EVENT HISTOGRAM (p3) - WITH FITTED CONTINUOUS DISTRIBUTIONS (NORMAL, STUDENT T, and GEV on log-transformed data) ---

# 1. Log-transform the non-zero area data
log_area_data <- wf_aoi$log_area_ha[wf_aoi$area_ha > 0]

# 2a. Fit Normal distribution to the logged data (for Log-Normal fit)
fit_norm <- MASS::fitdistr(log_area_data, "normal")
meanlog_fit <- fit_norm$estimate["mean"]
sdlog_fit <- fit_norm$estimate["sd"]

# 2b. Fit Student-t distribution to the logged data
# We'll use custom MLE fitting through fitdistrplus::fitdist
library(fitdistrplus)
fit_t <- MASS::fitdistr(log_area_data, "t")

t_mean <- fit_t$estimate["m"]
t_scale <- fit_t$estimate["s"]
t_df <- fit_t$estimate["df"]

# 2c. Fit Generalized Extreme Value (GEV) distribution to the logged data
fit_gev <- evd::fgev(log_area_data, std.err = FALSE)
gev_loc <- fit_gev$estimate["loc"]
gev_scale <- fit_gev$estimate["scale"]
gev_shape <- fit_gev$estimate["shape"]

# 3. Format parameters for subtitle
lognorm_meanlog <- format(meanlog_fit, digits = 2)
lognorm_sdlog <- format(sdlog_fit, digits = 2)
t_mean_f <- format(t_mean, digits = 2)
t_scale_f <- format(t_scale, digits = 2)
t_df_f <- format(t_df, digits = 2)
gev_loc_f <- format(gev_loc, digits = 2)
gev_scale_f <- format(gev_scale, digits = 2)
gev_shape_f <- format(gev_shape, digits = 2)

# Subtitle text
p3_subtitle <- paste0(
  "Norm [dashed] (μ, σ): ", lognorm_meanlog, ", ", lognorm_sdlog,
  " | Student-t [dotted] (m, s, df): ", t_mean_f, ", ", t_scale_f, ", ", t_df_f,
  " | GEV [solid] (μ, σ, ξ): ", gev_loc_f, ", ", gev_scale_f, ", ", gev_shape_f
)

# 4. Create the plot using the logged data on the X-axis
p3 <- wf_aoi %>%
  ggplot(aes(x = log_area_ha)) +
  
  # Histogram of log-transformed data (density scale)
  geom_histogram(
    aes(y = after_stat(density)),
    bins = 50,
    fill = "#fb9a99",
    color = "white"
  ) +
  
  # 1. Normal Fit (Blue Dashed)
  stat_function(
    fun = dnorm,
    args = list(mean = meanlog_fit, sd = sdlog_fit),
    color = "#1f78b4",
    linewidth = 1,
    linetype = "dashed"
  ) +
  
  # 2. Student-t Fit (Red Dotted)
  stat_function(
    fun = function(x) dt((x - t_mean) / t_scale, df = t_df) / t_scale,
    color = "#e31a1c",
    linewidth = 1,
    linetype = "dotted"
  ) +
  
  # 3. GEV Fit (Purple Solid)
  stat_function(
    fun = evd::dgev,
    args = list(loc = gev_loc, scale = gev_scale, shape = gev_shape),
    color = "#7570b3",
    linewidth = 1,
    linetype = "solid"
  ) +
  
  labs(
    title = "C: Area Per Event Distribution (Log-Scale with Dual Fit)",
    subtitle = p3_subtitle,
    x = "Area per Event (ha)",
    y = "Density"
  ) +
  
  # Display log10 axis labels (convert from log-values)
  scale_x_continuous(
    labels = function(x) {
      parse(text = paste0("10^", round(x / log(10), 0)))
    },
    breaks = log(c(1, 10, 100, 1000, 10000, 100000))
  ) +
  
  coord_cartesian(xlim = range(log_area_data)) +
  
  theme_minimal() +
  theme(
    plot.title = element_text(size = 11, hjust = 0.5, face = "bold"),
    plot.subtitle = element_text(size = 7, hjust = 0.5),
    plot.margin = margin(5, 5, 5, 5)
  )

# Print plot
p3




# --- 6. COMBINE PLOTS using ggpubr ---
final_plot <- ggarrange(
  p1, p2, p3,
  ncol = 1, nrow = 3,
  heights = c(0.4, 0.3, 0.3) # 50% for p1, 50% for the stacked histograms
)

# Print the final arranged plot
print(final_plot)
























library(mapview)
mapview(wf_aoi, zcol = "year", legend = TRUE, layer.name = "Wildfires") +
  # add convex hull polygon, no fill, just border
  mapview(ch, color = "black", lwd = 2, layer.name = "Convex Hull")
  

hist(wf_aoi$area_ha, breaks = 50, 
     main = "Distribution of Burned Area (ha)", 
     xlab = "Area (ha)")



##### Ignition probability #####



wildfire_centroids <- st_centroid(wf_aoi) |>
  st_transform(crs = st_crs(grd))

overlay <- st_join(grd, wildfire_centroids)
overlay$wildfire <- ifelse(is.na(overlay$CODI_FINAL), 0, 1)

overlay_rest <- overlay[overlay$lc_artificial < 0.1, ]
table(overlay_rest$wildfire)

# density of access grouped by wildfire
library(ggplot2)

ggplot(overlay_rest, aes(x = road_distance, fill = as.factor(wildfire))) +
  geom_density(alpha = 0.5) +
  labs(title = "Density of Road Distance by Wildfire Occurrence",
       x = "Road distance",
       fill = "Wildfire Occurrence [m]") +
  theme_minimal()



# logistic regression, exclude urban areas
m1 <- glm(wildfire ~ ignition_probability_surface, data = overlay_rest, 
          family = binomial(link = "logit"))
summary(m1)






#### test SAL cost assumptions ####
# two random correlated variables with rho = 0.5
library(mvtnorm)
library(tidyverse)

set.seed(123)
n <- 10000

mu <- c(0, 0)
rho <- 0.5

sigma <- matrix(c(1, rho, rho, 1), nrow = 2)

data <- rmvnorm(n, mean = mu, sigma = sigma)
colnames(data) <- c("slope", "access")

# create a data frame
df <- data.frame(slope = data[, 1], access = data[, 2]) |>
  # scale both to 0-1, making new variables
  mutate(slope_sc = (slope - min(slope)) / (max(slope) - min(slope)),
         access_sc = (access - min(access)) / (max(access) - min(access))) |>
  # add scaled variables
  mutate(slope_access_add = slope_sc + access_sc) |>
  # multiply scaled variables
  mutate(slope_access_mult = slope_sc * access_sc)

# make two plots in one
par(mfrow = c(2, 1))
hist(df$slope_access_add, main = "Sum of Scaled Variables", xlab = "Sum")
hist(df$slope_access_mult, main = "Product of Scaled Variables", xlab = "Product")
par(mfrow = c(1, 1))