# Historic wildfire ignition pattern

# Setup

setwd("C:/Users/DaSchulz/OneDrive - European Forest Institute/Dokumente/research/bcnfire")

# load all shp files in subfolder of ./data/wildfires/wildfires_shp
library(sf)
library(tidyverse)
library(stringr)
library(osmextract)
library(fs)

# study region: Catalunya
# load grd shape
grd <- st_read("./data/rdat/grd_filt.gpkg")

comarcas <- st_read("./data/divisions-administratives-v2r1-20250101/divisions-administratives-v2r1-comarques-1000000-20250101.json") |> 
  st_transform(crs = st_crs(grd)) |> 
  st_sf() |>       
  st_make_valid()

aoi <- st_union(comarcas)


# make 1km grid across study region
catalunya_grd <- st_make_grid(comarcas, 
                              cellsize = units::as_units(1000, "meter")) |> 
  st_make_valid() |> 
  st_intersection(aoi)
catalunya_grd <- st_sf(id = 1:length(catalunya_grd), geometry = catalunya_grd)


mapview::mapview(catalunya_grd)

# load wildfire data, calculate centroids, 
wildfires <- list.files("./data/wildfires/wildfires_shp", pattern = ".shp$", 
                        recursive = TRUE, full.names = TRUE, include.dirs = TRUE) |>
  lapply(st_read) |>
  bind_rows()

wildfires <- wildfires |>
  filter(!is.na(CODI_FINAL)) |>
  mutate(
    year = case_when(nchar(DATA_INCEN) == 7 ~ as.integer(paste0("20", substr(DATA_INCEN, 6, 7))),
                     nchar(DATA_INCEN) == 8 ~ as.integer(paste0("20", substr(DATA_INCEN, 7, 8))),
                     nchar(DATA_INCEN) >= 10 ~ as.integer(substr(DATA_INCEN, 7, 10)),
                     TRUE ~ NA),
    month = case_when(nchar(DATA_INCEN) == 7 ~ as.integer(substr(DATA_INCEN, 3, 4)),
                      nchar(DATA_INCEN) >= 8 ~ as.integer(substr(DATA_INCEN, 4, 5)),
                      TRUE ~ NA),
    # day is anything before first slash
    day = as.integer(substring(DATA_INCEN, 1, regexpr("/", DATA_INCEN) - 1)),
    date = as.Date(paste(year, month, day, sep = "-"), format = "%Y-%m-%d"),
    area_ha = as.numeric(st_area(geometry)) / 10000,  # convert from m² to ha
    MUNICIPI = str_to_title(MUNICIPI)  # capitalize first letter of each word
  ) |>
  select(CODI_FINAL, MUNICIPI, date, year, month, area_ha, geometry)


# transform crs
wildfires <- st_transform(wildfires, crs = st_crs(grd)) %>%
  st_make_valid()

wildfire_centroids <- st_centroid(wildfires)

mapview::mapview(wildfire_centroids)

# join with grid data
wf_dat <- st_join(catalunya_grd, wildfire_centroids, join = st_intersects) |>
  mutate(any_wildfire = ifelse(!is.na(CODI_FINAL), 1, 0))

table(wf_dat$any_wildfire)

# load predictor data, extract to grid



setwd("C:/Users/DaSchulz/OneDrive - European Forest Institute/wild-E/CS4_Barcelona")
# ---------------------------------------
# 1. Download Geofabrik extract (Catalonia)
# ---------------------------------------
# Default download folder (~/.osmextract by default)

its_match = oe_match("catalonia", quiet = TRUE)

oe_download(
  file_url = its_match$url,
  file_size = its_match$file_size,
  file_basename = "catalonia",
  provider = "geofabrik", 
  download_directory = "./data/osm"
)

pbf_path <- "./data/osm/geofabrik_catalonia.pbf"

osm_lines <- oe_read(pbf_path, layer = "lines")
osm_points <- oe_read(pbf_path, layer = "points")

ht = c("primary", "secondary", "tertiary", "unclassified") # highway types of interest
trails <- c("footway", "path", "pedestrian", "residential", "track")

osm_major_roads = osm_lines[osm_lines$highway %in% ht, ]
hiking_catalunya = osm_lines[osm_lines$highway %in% trails,]

cycleways_catalunya = osm_lines[osm_lines$highway == 'cycleway',]


#foot_ways <- osm_lines[grepl("footway", osm_lines$other_tags),]

camp_sites <- osm_points[grepl("tourism", osm_points$other_tags) & 
                           grepl("camp_site", osm_points$other_tags),]

# extract data
osm_major_roads <- st_transform(osm_major_roads, crs= st_crs(grd))
cycleways_catalunya <- st_transform(cycleways_catalunya, crs= st_crs(grd))
hiking_catalunya <- st_transform(hiking_catalunya, crs= st_crs(grd))
camp_sites <- st_transform(camp_sites, crs= st_crs(grd))

# -----------------------------------------------------
# 5. Compute intersection & density
# -----------------------------------------------------
library(units)
# Intersect roads with grid cells
major_roads_split <- st_intersection(osm_major_roads, catalunya_grd)
cycle_roads_split <- st_intersection(cycleways_catalunya, catalunya_grd)
hiking_roads_split <- st_intersection(hiking_catalunya, catalunya_grd)


# Compute lengths (in km)
major_roads_split$length_km <- set_units(st_length(major_roads_split), "km") %>% units::drop_units()
cycle_roads_split$length_km <- set_units(st_length(cycle_roads_split), "km") %>% units::drop_units()
hiking_roads_split$length_km <- set_units(st_length(hiking_roads_split), "km") %>% units::drop_units()

# Sum length per grid cell
major_road_density_df <- major_roads_split |>
  st_drop_geometry() |>
  group_by(id) |>
  summarise(major_road_total_length_km = sum(length_km, na.rm = TRUE))
cycle_road_density_df <- cycle_roads_split |>
  st_drop_geometry() |>
  group_by(id) |>
  summarise(cycle_road_total_length_km = sum(length_km, na.rm = TRUE))
hiking_road_density_df <- hiking_roads_split |>
  st_drop_geometry() |>
  group_by(id) |>
  summarise(hiking_road_total_length_km = sum(length_km, na.rm = TRUE))

# Merge back to grid
catalunya_grd <- catalunya_grd |>
  left_join(major_road_density_df, by = "id") |>
  left_join(cycle_road_density_df, by = "id") |>
  left_join(hiking_road_density_df, by = "id")

# Compute grid cell area (in km²)
catalunya_grd$area_km2 <- set_units(st_area(catalunya_grd), "km^2") %>% drop_units()

# Density = km of trails / km²
catalunya_grd <- catalunya_grd |>
  mutate(major_road_density_km_per_km2 = major_road_total_length_km / area_km2,
         cycle_road_density_km_per_km2 = cycle_road_total_length_km / area_km2,
         hiking_road_density_km_per_km2 = hiking_road_total_length_km / area_km2) %>%
  replace_na(list(major_road_density_km_per_km2 = 0, 
                  cycle_road_density_km_per_km2 = 0,
                  hiking_road_density_km_per_km2 = 0))


# distance to closest campsite
catalunya_grd_centroids <- st_centroid(catalunya_grd)

# ------------------------------------------------------------
# Calculate nearest campsite distance for each centroid
# ------------------------------------------------------------
# st_distance returns a dense distance matrix [n_grids x n_campsites],
# so we use apply() to extract the minimum per row.
dist_mat <- st_distance(catalunya_grd_centroids, camp_sites)  # units: meters

# Convert to km and extract minimum distance
catalunya_grd$dist_min_camp_km <- apply(dist_mat, 1, min)/1000 %>%
  set_units("km") %>%
  drop_units()




## export as raster
grd_vect <- vect(catalunya_grd)
res_m <- 1000
r_template <- rast(ext(grd_vect), resolution = res_m, crs = crs(grd_vect))
r_cycle_road_density_km_per_km2 <- rasterize(grd_vect, r_template, field = "cycle_road_density_km_per_km2")
r_major_road_density_km_per_km2 <- rasterize(grd_vect, r_template, field = "major_road_density_km_per_km2")
r_hiking_road_density_km_per_km2 <- rasterize(grd_vect, r_template, field = "hiking_road_density_km_per_km2")
r_dist_min_camp_km <- rasterize(grd_vect, r_template, field = "dist_min_camp_km")

r_infrastructure <- c(r_major_road_density_km_per_km2, 
                      r_cycle_road_density_km_per_km2,
                      r_hiking_road_density_km_per_km2,
                      r_dist_min_camp_km)
names(r_infrastructure) <- c("major_road_density", "cycle_road_density", "trail_density", "campsite_distance")


writeRaster(r_infrastructure, "./data/rdat/r_infrastructure.tif", overwrite = TRUE)




# load and extract landcover and topography
path_topo <- "./data/topo/topo_bcn.tif"
path_lc_rcl <- "./data/landcover/BMRlandcover_rcl.tif"
path_infra <- "./data/rdat/r_infrastructure.tif"

library(terra)
rast_topo <- rast(path_topo)
rast_lc <- rast(path_lc_rcl)

e_topo <- exactextractr::exact_extract(rast_topo, catalunya_grd, fun = "mean")
e_lc <- exactextractr::exact_extract(rast_lc, catalunya_grd, fun = "frac")

# merge with grid
catalunya_grd <- bind_cols(catalunya_grd, e_topo)
catalunya_grd <- bind_cols(catalunya_grd, e_lc)

catalunya_grd <- catalunya_grd %>%
  replace_na(list(mean.slope = 0, 
                  mean.elev = 0,
                  mean.aspect = 0))

r_elev <- rasterize(grd_vect, r_template, field = "mean.elev")
r_slope <- rasterize(grd_vect, r_template, field = "mean.slope")
r_aspect <- rasterize(grd_vect, r_template, field = "mean.aspect")
r_frac1 <- rasterize(grd_vect, r_template, field = "frac_1")
r_frac2 <- rasterize(grd_vect, r_template, field = "frac_2")
r_frac3 <- rasterize(grd_vect, r_template, field = "frac_3")
r_frac4 <- rasterize(grd_vect, r_template, field = "frac_4")
r_frac5 <- rasterize(grd_vect, r_template, field = "frac_5")

r_topo <- c(r_elev, r_slope, r_aspect)



r_lc <- c(r_frac1, r_frac2, r_frac3, r_frac4, r_frac5)

writeRaster(r_topo, "./data/rdat/r_topo_catalunya.tif", overwrite = TRUE)
writeRaster(r_lc, "./data/rdat/r_lc_catalunya.tif", overwrite = TRUE)

path_topo <- "./data/rdat/r_topo_catalunya.tif"
path_lc_rcl <- "./data/rdat/r_lc_catalunya.tif"

# save grid
save(catalunya_grd, file ="./catalunya_grd.RData")


rast_infra <- raster::raster(path_infra)
rast_topo <- raster::raster(path_topo)
rast_lc <- raster::raster(path_lc_rcl)

# maxent

library(dismo)
library(terra)
library(sf)
library(dplyr)

# Fire ignition points (sf)
wildfire_points <- wildfire_centroids %>%
  st_transform(4326)

# Convert to SpatialPoints for dismo
wildfire_sp <- as_Spatial(st_geometry(wildfire_points))


env_stack <- stack(rast_topo, rast_lc, rast_infra)
# Convert SpatRaster to RasterStack
library(raster)

# MaxEnt requires Java — install Java JDK if not present
mask <- vect(aoi)

# check NA
na_ex <- extract(env_stack, wildfire_sp)


wildfire_sp <- wildfire_sp[complete.cases(na_ex),]


# Run MaxEnt
me <- dismo::maxent(
  x = env_stack,
  p = wildfire_sp,
  path = "./data/maxent_fire/",
  args = c("replicates=1", "responsecurves=true")
)

install.packages("ENMeval")
library(ENMeval)
library(terra)

# Predictor rasters (SpatRaster fine)
# wildfire_sf = sf object with ignitions

presence <- st_coordinates(wildfire_points)  # matrix of lon/lat

eval <- ENMevaluate(
  occs = presence,
  envs = env_stack,
  method = 'block',
  algorithm = 'maxent.jar',
  fc = "L",   # feature classes
  RMvalues = seq(1, 3, 0.5)
)


# ignition risk map

